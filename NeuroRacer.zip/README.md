# neurorace
Neuro Racer is a mod for Assetto Corsa designed to measure available cognitive abilities while racing.

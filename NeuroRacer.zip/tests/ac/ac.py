

def console(message):
    print(message)

def log(message):
    print(message)

def setSize(app_window, x, y):
    return

def addRenderCallback(app_window, render_function):
    return

def setBackgroundOpacity(app_window, opacity):
    return

def drawBorder(app_window, width):
    return

def setTitle(app_window, title):
    return

def addLabel(app_window, label):
    return

def glQuadTextured(x, y, w, h, color):
    return

def deleteApp(app_window):
    return

def newApp(app_name):
    return

def newTexture(image_path):
    return